<?php

$con = mysql_connect("localhost", "root", "") or die("Could not connect to MySQL");
mysql_select_db("htc") or die("Could not select db");

?>